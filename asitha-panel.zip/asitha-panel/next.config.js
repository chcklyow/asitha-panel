module.exports = {
  reactStrictMode: true
};